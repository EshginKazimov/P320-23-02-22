﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace P320FrontToBack.Models
{
    public class User : IdentityUser
    {
        [Required]
        public string Fullname { get; set; }
    }
}
