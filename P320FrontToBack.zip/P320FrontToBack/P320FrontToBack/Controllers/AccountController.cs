﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using P320FrontToBack.Models;
using P320FrontToBack.ViewModels;
using System.Threading.Tasks;

namespace P320FrontToBack.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<User> _userManager;
        private readonly SignInManager<User> _signInManager;

        public AccountController(UserManager<User> userManager, SignInManager<User> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel registerModel)
        {
            if (!ModelState.IsValid)
                return View();

            var existUser = await _userManager.FindByNameAsync(registerModel.Username);
            if (existUser != null)
            {
                ModelState.AddModelError("Username", "Bu adda user var.");
                return View();
            }

            var user = new User
            {
                Email = registerModel.Email,
                UserName = registerModel.Username,
                Fullname = registerModel.Fullname
            };

            var result = await _userManager.CreateAsync(user, registerModel.Password);
            if (!result.Succeeded)
            {
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }

                return View();
            }

            await _signInManager.SignInAsync(user, false);

            return RedirectToAction("Index", "Home");
        }

        public IActionResult Login()
        {
            return View();
        }
    }
}
